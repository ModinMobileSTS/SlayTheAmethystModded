Slay the Amethyst 诊断日志包

目录说明：
- easytier/：EasyTier 配置、当前状态，以及最近 5 条断开/重连/失败记录（含 :easytier 进程退出原因）。
- feedback/：反馈提交所需的 issue 内容、请求信息和日志摘要；该目录保持反馈包原结构。
- info/：设备信息和启动器设置。
- logs/：JVM 日志及启动桥接、GC、堆快照、信号转储等启动器日志，JVM 日志最多保留 5 槽位。
- achievement_sync/：成就请求解析、游戏内弹窗、Steam 查询、上传及失败事件，最多保留 3 槽位，不包含 Steam 凭据。
- memory_diagnostics/：内存压力和内存诊断日志，最多保留 5 槽位。
- window/：游戏窗口、viewport、Surface、尺寸同步和触控坐标映射诊断日志，最多保留 3 槽位。
- logcat/app/：应用进程 logcat，最多 5 槽位。
- logcat/system/：系统进程 logcat，最多 5 槽位。
- launcher_crash_reports/：启动器崩溃报告，最多 5 槽位。
- steam_login/：Steam credentials 登录失败记录，最多 5 槽位。
- steam_cloud/：Steam Cloud 操作、失败历史和协议诊断信息。
- steam-game-presence/：Steam 在线状态上报的最后摘要和连续事件日志，最多保留 3 槽位。
- workshop/market_failed/：Workshop 市场查询失败日志，最多 5 槽位。
- workshop/download_tasks/：最近 10 条 Workshop 下载任务日志。
- workshop/auto_import_patch_logs/：自动导入补丁日志，最多 10 槽位。
- crash/：本次崩溃归档的摘要（仅崩溃报告包包含）。

已从导出包移除：jvm_histograms/、performance_launch_audit.log、process_exit_info.txt。
某些目录或文件在没有对应事件时不会生成。
